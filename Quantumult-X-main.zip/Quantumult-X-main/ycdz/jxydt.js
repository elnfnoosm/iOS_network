/******************************

脚本功能：驾校一点通+解锁VIP
特别注意：必须v10.6.2版本
软件版本：v10.6.2
脚本作者：彭于晏
更新时间：2022-9-8
问题反馈：QQ+89996462
TG反馈群：https://t.me/plus8889
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️


*******************************

[rewrite_local]

^https:\/\/vipapi\.jxedt\.com\/store\/vip\/check url script-response-body https://raw.githubusercontent.com/89996462/Quantumult-X/main/ycdz/jxydt.js

[mitm] 
hostname = vipapi.jxedt.com


*******************************/

var _0x4cbf=['A8ONwr3DjsOZJC1MU8OVwoPDmMOwSFkSRlbCm8K1fcOKAcK1w6nDncKjIcKWwpLCh8Khw4dPccORDW83IXbDrinDrMKzwoHCikjDnzzCpcOrN8OzwqfDug8yEFR6VEdkOUvDtsKvB8KkJSYPw6XCjHd4w7hoQFfCoMOwXQ0IT8Kyw5HDlcOKNA3DsMKow6lgfF3CrsKYw7REIMOOwp7DvEIPwqcMDT3Dm8KEwrcfBMOkC8ORw7PDm8KxLcOGd2LCjgzDsVXCrjzCjDl/C8O4worDhngKaGk9wrNmw4HCt8KJBSoNWcK0wq9CZMOMwqgww6/Dq8Ksdh7CmVZTwoEowrrDiMK2FVzCrcKFWSdNDsOkfQrDm8OvXcORwqDCosKFFXJqw6clwpHDlsKCwrTDpsK4aEIsw4TDg8OyXcKaAFPCqMKrV8KoMcKaBgjCkRrDqMOzLMO7VhIBLsO+ERsVw4g7wrbDpVnDuDPDv8Kkw7Q0w4XCtwhKL8OaKVIMasKjw4lZJxJTThQMFcOJwo3CrBhpw7zCk8KCHsOkwqbDkAjClsKtwo3Dk8OEbxZ1w6Atw4XCu8KCwpU6JlvCq8OnwpMrw7w2wpgRw63DpsKuOFU5w5LCtcKww6o/CjnDk8O9LSPDkwAQwrTDhRDCvcKFZw/ChS3CusOew5pVwp0ewp07w40r','w7/CvjrCrA==','wrhUex8dGcORwphW'];(function(_0x5e5dfd,_0x4cbf18){var _0x5b86c9=function(_0x2ea69d){while(--_0x2ea69d){_0x5e5dfd['push'](_0x5e5dfd['shift']());}};_0x5b86c9(++_0x4cbf18);}(_0x4cbf,0x1f0));var _0x5b86=function(_0x5e5dfd,_0x4cbf18){_0x5e5dfd=_0x5e5dfd-0x0;var _0x5b86c9=_0x4cbf[_0x5e5dfd];if(_0x5b86['ckzTTz']===undefined){(function(){var _0x5d36f7=function(){var _0x47cb4a;try{_0x47cb4a=Function('return\x20(function()\x20'+'{}.constructor(\x22return\x20this\x22)(\x20)'+');')();}catch(_0x599c6b){_0x47cb4a=window;}return _0x47cb4a;};var _0x16ed98=_0x5d36f7();var _0x17bc76='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x16ed98['atob']||(_0x16ed98['atob']=function(_0x2b6ef8){var _0x548e0d=String(_0x2b6ef8)['replace'](/=+$/,'');var _0xfa0534='';for(var _0x48b8c8=0x0,_0x3b2b1c,_0x137522,_0x2f29ac=0x0;_0x137522=_0x548e0d['charAt'](_0x2f29ac++);~_0x137522&&(_0x3b2b1c=_0x48b8c8%0x4?_0x3b2b1c*0x40+_0x137522:_0x137522,_0x48b8c8++%0x4)?_0xfa0534+=String['fromCharCode'](0xff&_0x3b2b1c>>(-0x2*_0x48b8c8&0x6)):0x0){_0x137522=_0x17bc76['indexOf'](_0x137522);}return _0xfa0534;});}());var _0x31a844=function(_0x54048d,_0x528b33){var _0x2e0ed1=[],_0x31092c=0x0,_0x5d9eb9,_0x1b2b28='',_0x4b2057='';_0x54048d=atob(_0x54048d);for(var _0x33644e=0x0,_0xd3f345=_0x54048d['length'];_0x33644e<_0xd3f345;_0x33644e++){_0x4b2057+='%'+('00'+_0x54048d['charCodeAt'](_0x33644e)['toString'](0x10))['slice'](-0x2);}_0x54048d=decodeURIComponent(_0x4b2057);var _0x177882;for(_0x177882=0x0;_0x177882<0x100;_0x177882++){_0x2e0ed1[_0x177882]=_0x177882;}for(_0x177882=0x0;_0x177882<0x100;_0x177882++){_0x31092c=(_0x31092c+_0x2e0ed1[_0x177882]+_0x528b33['charCodeAt'](_0x177882%_0x528b33['length']))%0x100;_0x5d9eb9=_0x2e0ed1[_0x177882];_0x2e0ed1[_0x177882]=_0x2e0ed1[_0x31092c];_0x2e0ed1[_0x31092c]=_0x5d9eb9;}_0x177882=0x0;_0x31092c=0x0;for(var _0x2ac356=0x0;_0x2ac356<_0x54048d['length'];_0x2ac356++){_0x177882=(_0x177882+0x1)%0x100;_0x31092c=(_0x31092c+_0x2e0ed1[_0x177882])%0x100;_0x5d9eb9=_0x2e0ed1[_0x177882];_0x2e0ed1[_0x177882]=_0x2e0ed1[_0x31092c];_0x2e0ed1[_0x31092c]=_0x5d9eb9;_0x1b2b28+=String['fromCharCode'](_0x54048d['charCodeAt'](_0x2ac356)^_0x2e0ed1[(_0x2e0ed1[_0x177882]+_0x2e0ed1[_0x31092c])%0x100]);}return _0x1b2b28;};_0x5b86['AZoOmC']=_0x31a844;_0x5b86['hxzbae']={};_0x5b86['ckzTTz']=!![];}var _0x2ea69d=_0x5b86['hxzbae'][_0x5e5dfd];if(_0x2ea69d===undefined){if(_0x5b86['fzxuqS']===undefined){_0x5b86['fzxuqS']=!![];}_0x5b86c9=_0x5b86['AZoOmC'](_0x5b86c9,_0x4cbf18);_0x5b86['hxzbae'][_0x5e5dfd]=_0x5b86c9;}else{_0x5b86c9=_0x2ea69d;}return _0x5b86c9;};var body=$response[_0x5b86('0x0','8gAI')];var objk=JSON['parse'](body);objk={'code':0x0,'result':{'vipCheckResult':_0x5b86('0x2','WYk9')},'msg':'ok'};body=JSON[_0x5b86('0x1','pHGL')](objk);$done({'body':body});
