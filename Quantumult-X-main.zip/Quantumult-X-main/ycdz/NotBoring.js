/******************************

脚本功能：Not Boring +解锁订阅
特别通知：可以解锁全家桶！四件套💓
下载地址：https://is.gd/LGpKsj
软件版本：2.7
脚本作者：彭于晏💞
更新时间：2022-9-29
问题反馈：QQ+89996462
QQ会员群：779392027💞
TG反馈群：https://t.me/plus8889
TG频道群：https://t.me/py996
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️

*******************************

[rewrite_local]

^https?:\/\/api-weather\.andy\.works\/v\d\/\w{18}$ url script-response-body https://raw.githubusercontent.com/89996462/Quantumult-X/main/ycdz/NotBoring.js

[mitm] 

hostname = api-weather.andy.works


*******************************/


const _0x5d81=['CQHDpMKYwqtEG29kLVXCocK2wr/DvQ==','wr9fXcKTWFN2wrDDpsOBw7LDtk/DrsO4w6LCugpIwr5w','w6XDuhjDt8KRNRci','w4TCu8O2dMKfwqzDhTnCssOiXBPDjmcBZwZkccOeJcOgdSTCnsOjUQJtCDzCksOEJA==','w6wuEMOQZw==','wogmwqXDoHTDkGg6w75oDMKgL2dDF0DClwvCrGHDrws2DsK/WsKEw4XDo8OcwqFqXA==','wp9Lw4RSwohNwozCgDE='];(function(_0x20da79,_0x5d818e){const _0x1c304c=function(_0x1be2e3){while(--_0x1be2e3){_0x20da79['push'](_0x20da79['shift']());}};_0x1c304c(++_0x5d818e);}(_0x5d81,0xee));const _0x1c30=function(_0x20da79,_0x5d818e){_0x20da79=_0x20da79-0x0;let _0x1c304c=_0x5d81[_0x20da79];if(_0x1c30['WOHpHT']===undefined){(function(){let _0x4ef0ab;try{const _0x3d6695=Function('return\x20(function()\x20'+'{}.constructor(\x22return\x20this\x22)(\x20)'+');');_0x4ef0ab=_0x3d6695();}catch(_0x1600bb){_0x4ef0ab=window;}const _0x13fab0='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x4ef0ab['atob']||(_0x4ef0ab['atob']=function(_0x1958fb){const _0x3da83b=String(_0x1958fb)['replace'](/=+$/,'');let _0x5a7e5f='';for(let _0x470ce5=0x0,_0xf9e05d,_0x391565,_0x2f6d1b=0x0;_0x391565=_0x3da83b['charAt'](_0x2f6d1b++);~_0x391565&&(_0xf9e05d=_0x470ce5%0x4?_0xf9e05d*0x40+_0x391565:_0x391565,_0x470ce5++%0x4)?_0x5a7e5f+=String['fromCharCode'](0xff&_0xf9e05d>>(-0x2*_0x470ce5&0x6)):0x0){_0x391565=_0x13fab0['indexOf'](_0x391565);}return _0x5a7e5f;});}());const _0x13a1c6=function(_0x489c14,_0x120f58){let _0x59674a=[],_0x1e1070=0x0,_0x555abc,_0x322ca6='',_0x2fa5c7='';_0x489c14=atob(_0x489c14);for(let _0x2af019=0x0,_0x15bdbc=_0x489c14['length'];_0x2af019<_0x15bdbc;_0x2af019++){_0x2fa5c7+='%'+('00'+_0x489c14['charCodeAt'](_0x2af019)['toString'](0x10))['slice'](-0x2);}_0x489c14=decodeURIComponent(_0x2fa5c7);let _0xdda230;for(_0xdda230=0x0;_0xdda230<0x100;_0xdda230++){_0x59674a[_0xdda230]=_0xdda230;}for(_0xdda230=0x0;_0xdda230<0x100;_0xdda230++){_0x1e1070=(_0x1e1070+_0x59674a[_0xdda230]+_0x120f58['charCodeAt'](_0xdda230%_0x120f58['length']))%0x100;_0x555abc=_0x59674a[_0xdda230];_0x59674a[_0xdda230]=_0x59674a[_0x1e1070];_0x59674a[_0x1e1070]=_0x555abc;}_0xdda230=0x0;_0x1e1070=0x0;for(let _0x599d09=0x0;_0x599d09<_0x489c14['length'];_0x599d09++){_0xdda230=(_0xdda230+0x1)%0x100;_0x1e1070=(_0x1e1070+_0x59674a[_0xdda230])%0x100;_0x555abc=_0x59674a[_0xdda230];_0x59674a[_0xdda230]=_0x59674a[_0x1e1070];_0x59674a[_0x1e1070]=_0x555abc;_0x322ca6+=String['fromCharCode'](_0x489c14['charCodeAt'](_0x599d09)^_0x59674a[(_0x59674a[_0xdda230]+_0x59674a[_0x1e1070])%0x100]);}return _0x322ca6;};_0x1c30['nhGQXh']=_0x13a1c6;_0x1c30['YyIOiJ']={};_0x1c30['WOHpHT']=!![];}const _0x1be2e3=_0x1c30['YyIOiJ'][_0x20da79];if(_0x1be2e3===undefined){if(_0x1c30['XrDUOF']===undefined){_0x1c30['XrDUOF']=!![];}_0x1c304c=_0x1c30['nhGQXh'](_0x1c304c,_0x5d818e);_0x1c30['YyIOiJ'][_0x20da79]=_0x1c304c;}else{_0x1c304c=_0x1be2e3;}return _0x1c304c;};let obj=JSON[_0x1c30('0x4','XLI%')]($response['body']);obj={'latestSubscriptionReceipts':[{'productId':_0x1c30('0x5','EJ3$'),'autoRenewProductId':_0x1c30('0x3','wMfX'),'authToken':'','purchaseDateMs':0x1814f08ed10,'autoRenewStatus':'1','originalTransactionId':_0x1c30('0x0','(Owo'),'sourceBundleId':_0x1c30('0x1','PBIA'),'expiresDateMs':0xe675eebf145d,'isInBillingRetryPeriod':![],'cancellationDateMs':null,'isOriginalBeliever':![],'isTrialPeriod':!![],'originalPurchaseDateMs':0x1814f08f0f8,'groupId':_0x1c30('0x2','13H&'),'expirationIntent':'','lastRefreshDateMs':0x1afdffba02d}]};$done({'body':JSON[_0x1c30('0x6','f6Ws')](obj)});
