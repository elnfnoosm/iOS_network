/******************************

脚本功能：Nicegram: Unlimited Text+解锁订阅
下载地址：https://is.gd/7OPpId
软件版本：1.1.2
脚本作者：彭于晏💞
更新时间：2022-10-8
问题反馈：QQ+89996462
QQ会员群：779392027💞
TG反馈群：https://t.me/plus8889
TG频道群：https://t.me/py996
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️

*******************************

[rewrite_local]

https?:\/\/restore-access\.indream\.app\/restoreAccess\?id=\d{5,10} url echo-response text/json echo-response https://raw.githubusercontent.com/89996462/Quantumult-X/main/ycdz/Nicegram.js

[mitm] 
hostname=restore-access.indream.app


*******************************/
