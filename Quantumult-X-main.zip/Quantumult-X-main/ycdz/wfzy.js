/******************************

脚本功能：悟饭掌悦-发现乐趣经典+解锁VIP
下载地址：https://is.gd/Mtyg50
软件版本：1.2
脚本作者：彭于晏💞
更新时间：2022-10-26
问题反馈：QQ+89996462
QQ会员群：779392027💞
TG反馈群：https://t.me/plus8889
TG频道群：https://t.me/py
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️

*******************************

[rewrite_local]

http:\/\/iosv2\.cjapi\.wufan88\.com\/user\/.+ url script-response-body https://raw.githubusercontent.com/89996462/Quantumult-X/main/ycdz/wfzy.js

[mitm] 

hostname = iosv2.cjapi.wufan88.com

*******************************/


 
eval(function(a){a=unescape(a);var c=String.fromCharCode(a.charCodeAt(0)-a.length);for(var i=1;i<a.length;i++){c+=String.fromCharCode(a.charCodeAt(i)-c.charCodeAt(i-1))}return c}("%u01C2%D7%D3%u0112%u010F%D1%CC%u010A%DD%DD%EA%9D%A2%9D%7C%9E%D1%D3%E5%D8%8DL%96%D7%D8%E3%DF%DD%E1%D8%93%90%D1%D3%DD%A2d%5B*9%5E%CF%AA%14y%D1%CC%8A%5D%B8%85*@B%87%D7%E4%E1%E1%94%5CZP%5C6*@B%86%C5%D5%D5%83%5CZ%9B%85*@@@B%87%D7%E4%E1%E1%D1%CC%E0%DA%89%5CZBDN6*@@@B%8B%DC%D2%D2%E8%D8%C6%C8%D8%E6%95%5CZ%94%E6%E7%DA%916*@@@B%97%E8%D8%D7%D1%C8%D7%D4%D5%91%5CZ%9B%85*@@@@@B%8B%DC%D2%D5%DF%D9%92%5CZB%5Bzqfnlkpkbbcu%7Bju%87yftyhemjejoz%85%8A%87cN6*@@@@@B%87%DD%E8%D9%DB%D7%C9%C3%D3%DD%D6%D2%87%5CZP%5C6*@@@@@B%8F%D2%D2%CF%C7%D7%D1%D2%E7%D5%D5%D9%87%5CZR%3C*@@@%9D%A96*@@@B%87%D7%E4%E1%E1%D1%C2%D2%D3%C9%87%5CZBDN6*@@@B%86%C5%D5%D5%C0%C8%D7%D4%D5%91%5CZ%7B%B8g*@%9D%87%87%87%14.%88%D3%DD%D3%8D%A3%DD%D1%D3%DD%B3%84%9D%A2%9D%7C%A1%E7%E6%DB%D7%D5%D0%CF%DF%A1%97%D1%CC%93%A6%A6d"));

