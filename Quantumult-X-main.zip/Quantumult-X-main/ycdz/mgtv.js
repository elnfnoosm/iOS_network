/******************************

脚本功能：美队tv（18+）+解锁VIP会员
下载地址：https://mdwy5.com/#/register?code=580580
下载地址：https://bxzb.lanzouv.com/iVSsU074rvyj
邀请码：666666 邀请码：580580
软件版本：v6666
脚本作者：彭于晏
更新时间：2022-9-
问题反馈：QQ+89996462
TG群：https://t.me/plus8889
使用声明：⚠️此脚本仅供学习与交流，请勿转载与贩卖！⚠️⚠️⚠️

/******************************

[rewrite_local]

^https:\/\/fcapi\.91por\.vip\/api\/video\/user\/info url script-response-body https://raw.githubusercontent.com/89996462/Quantumult-X/main/ycdz/mgtv.js

[mitm] 
hostname = fcapi.91por.vip



*******************************/


;var encode_version = 'jsjiami.com.v5', dnyew = '__0xe9d43',  __0xe9d43=['CSIPSn0=','5Ym76Zu654qZ5p6c5YyG776+wr5t5L+U5a2Q5p+45b2r56qy','wr8awrPCqMKE','w5AOFQnDqg4tdMK3w7JFfEo9DMKRNMONw4DDtC5rwoMCG8KCES3Cpm/DiMKnwqw/AX7CssKrwpBxw5Bqw4nCmsOvworDlcKDw4RHwpnCgsOiw6vCgsO4w77CpMOjwofDhklqwpfCkBzDmCvCu8O+w5VtPcO7woXDklxDwpE+w4ROwq55wrHCjsKowprCtcKEw5gmw4PCrMOCw4oJVsOIdFHDpcKHWCBwfMKdw5R6worCjMKrIDAYw4dvaMO9w71cw5fCpsOfwqR8FGPCiCs0CsKLBMO1w74sw44QYcK+Z8KqT2DCojQlw4jCuCFFY3cbwrrDmzVzwrcaWjY6w7vDnWXDhmR4w4IldxgCVCPCrsKOABdNPGw1wo3DvkRbU8OQwo7Ck2NRwpzDtMKoLW1lw7XDkcKMw5PCphjDnsOfw6Ywwo3CncK7w75lwrAeKsOXwr3DjsKDIcODw5TCq8OlHTTCvsO6wrRSw5/Co8KhwpnDnsO0FyHCl8K4TsKWwp/CssK2w4DCqMKGUcKhIg==','w5VeaMODwrXCr0vCtQ4=','wpDDicKuwp7Dq2hNwoTDow==','wrU8wqE3wqU2w6XCusOqQ8Ocw60XOw==','54qt5p6L5Yy977+3w6dy5Ly55a275p6Y5b+h56qU77yi6L6p6KyK5paL5o6x5oul5Lqm55iQ5beF5L2Q','w4vCrcK9DWU=','ShDCo0vCjw=='];(function(_0x10e788,_0x2228a4){var _0x9efd51=function(_0x58b996){while(--_0x58b996){_0x10e788['push'](_0x10e788['shift']());}};_0x9efd51(++_0x2228a4);}(__0xe9d43,0x106));var _0x5108=function(_0x324ad1,_0x3b9421){_0x324ad1=_0x324ad1-0x0;var _0x17a5a9=__0xe9d43[_0x324ad1];if(_0x5108['initialized']===undefined){(function(){var _0x1e5b1a=typeof window!=='undefined'?window:typeof process==='object'&&typeof require==='function'&&typeof global==='object'?global:this;var _0x20e4ba='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';_0x1e5b1a['atob']||(_0x1e5b1a['atob']=function(_0x224e9c){var _0xb6d974=String(_0x224e9c)['replace'](/=+$/,'');for(var _0x5181ac=0x0,_0x2309fb,_0x31e3b5,_0x52c411=0x0,_0xae1a45='';_0x31e3b5=_0xb6d974['charAt'](_0x52c411++);~_0x31e3b5&&(_0x2309fb=_0x5181ac%0x4?_0x2309fb*0x40+_0x31e3b5:_0x31e3b5,_0x5181ac++%0x4)?_0xae1a45+=String['fromCharCode'](0xff&_0x2309fb>>(-0x2*_0x5181ac&0x6)):0x0){_0x31e3b5=_0x20e4ba['indexOf'](_0x31e3b5);}return _0xae1a45;});}());var _0x55c510=function(_0x2ee33b,_0x521a1d){var _0x1ea0e1=[],_0x579d54=0x0,_0x43121c,_0xc0da1b='',_0x3068a2='';_0x2ee33b=atob(_0x2ee33b);for(var _0x4dbafd=0x0,_0x58fd40=_0x2ee33b['length'];_0x4dbafd<_0x58fd40;_0x4dbafd++){_0x3068a2+='%'+('00'+_0x2ee33b['charCodeAt'](_0x4dbafd)['toString'](0x10))['slice'](-0x2);}_0x2ee33b=decodeURIComponent(_0x3068a2);for(var _0x421b93=0x0;_0x421b93<0x100;_0x421b93++){_0x1ea0e1[_0x421b93]=_0x421b93;}for(_0x421b93=0x0;_0x421b93<0x100;_0x421b93++){_0x579d54=(_0x579d54+_0x1ea0e1[_0x421b93]+_0x521a1d['charCodeAt'](_0x421b93%_0x521a1d['length']))%0x100;_0x43121c=_0x1ea0e1[_0x421b93];_0x1ea0e1[_0x421b93]=_0x1ea0e1[_0x579d54];_0x1ea0e1[_0x579d54]=_0x43121c;}_0x421b93=0x0;_0x579d54=0x0;for(var _0x2c4f55=0x0;_0x2c4f55<_0x2ee33b['length'];_0x2c4f55++){_0x421b93=(_0x421b93+0x1)%0x100;_0x579d54=(_0x579d54+_0x1ea0e1[_0x421b93])%0x100;_0x43121c=_0x1ea0e1[_0x421b93];_0x1ea0e1[_0x421b93]=_0x1ea0e1[_0x579d54];_0x1ea0e1[_0x579d54]=_0x43121c;_0xc0da1b+=String['fromCharCode'](_0x2ee33b['charCodeAt'](_0x2c4f55)^_0x1ea0e1[(_0x1ea0e1[_0x421b93]+_0x1ea0e1[_0x579d54])%0x100]);}return _0xc0da1b;};_0x5108['rc4']=_0x55c510;_0x5108['data']={};_0x5108['initialized']=!![];}var _0x41c0d1=_0x5108['data'][_0x324ad1];if(_0x41c0d1===undefined){if(_0x5108['once']===undefined){_0x5108['once']=!![];}_0x17a5a9=_0x5108['rc4'](_0x17a5a9,_0x3b9421);_0x5108['data'][_0x324ad1]=_0x17a5a9;}else{_0x17a5a9=_0x41c0d1;}return _0x17a5a9;};var obj=JSON[_0x5108('0x0','QnTG')]($response['body']);obj={'code':0xc8,'data':_0x5108('0x1','oElT'),'msg':'成功'};$done({'body':JSON[_0x5108('0x2','Q7iK')](obj)});(function(_0x23cb77,_0x378208,_0x36ad34){var _0x1dac65={'ehytr':function _0x21f296(_0x3ba0b7,_0x24b162){return _0x3ba0b7!==_0x24b162;},'GoCYd':_0x5108('0x3','#C#1'),'xUqbe':function _0x361bfa(_0x1127f8,_0x11a4fa){return _0x1127f8===_0x11a4fa;},'YFYSs':_0x5108('0x4','^$p6'),'ybfue':function _0x243210(_0x51833b,_0x2ef875){return _0x51833b+_0x2ef875;},'PfrFR':_0x5108('0x5','#C#1')};_0x36ad34='al';try{_0x36ad34+='ert';_0x378208=encode_version;if(!(_0x1dac65[_0x5108('0x6','ImLp')](typeof _0x378208,_0x1dac65[_0x5108('0x7','8f6G')])&&_0x1dac65['xUqbe'](_0x378208,_0x1dac65['YFYSs']))){_0x23cb77[_0x36ad34](_0x1dac65[_0x5108('0x8','q%Ou')]('删除',_0x1dac65['PfrFR']));}}catch(_0x4e1006){_0x23cb77[_0x36ad34](_0x5108('0x9','#odW'));}}(window));;encode_version = 'jsjiami.com.v5';
